A Pen created at CodePen.io. You can find this one at https://codepen.io/nikhil/pen/GuAho.

 This is the search box by http://speckyboy.com/2012/02/15/how-to-build-a-stylish-css3-search-box/
feature on : http://thecodeblock.com/search-box-tutorials-using-css3-jquery/